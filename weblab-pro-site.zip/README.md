
# WebLab — Sito professionale (one‑page)

## Deploy su GitHub Pages
1. Vai su `giuppe5401-stack.github.io` → **Add file → Upload files**.
2. Trascina **tutto il contenuto** di questa cartella nella **root** del repo:
   - index.html
   - style.css
   - script.js
   - assets/logo/ (png, svg, ico)
   - assets/img/hero-bg.svg
3. **Commit changes** → apri `https://giuppe5401-stack.github.io/` e ricarica (Ctrl/Cmd+Shift+R).

## Personalizza
- Cambia e‑mail e WhatsApp in `index.html` (sezione Contatti).
- Modifica prezzi e voci nei Pacchetti.
- Sostituisci testi in “Chi sono” e “Servizi”.
